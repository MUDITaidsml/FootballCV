import pickle
import cv2
import numpy as np
import os
import sys 
sys.path.append('../')
from utils import measure_distance,measure_xy_distance

class CameraMovementEstimator():
    def __init__(self,frame):
        self.minimum_distance = 5

        self.lk_params = dict(
            winSize = (15,15),
            maxLevel = 2,
            criteria = (cv2.TERM_CRITERIA_EPS | cv2.TERM_CRITERIA_COUNT,10,0.03)
        )

        first_frame_grayscale = cv2.cvtColor(frame,cv2.COLOR_BGR2GRAY)
        h, w = first_frame_grayscale.shape[:2]
        mask_features = np.zeros_like(first_frame_grayscale)
        # Use relative column ranges instead of hardcoded pixel values
        left_band = max(1, int(w * 0.02))       # ~first 2% of width
        right_start = max(0, int(w * 0.85))      # last 15% of width
        right_end = min(w, int(w * 0.98))
        mask_features[:, 0:left_band] = 1
        mask_features[:, right_start:right_end] = 1

        self.features = dict(
            maxCorners = 100,
            qualityLevel = 0.3,
            minDistance =3,
            blockSize = 7,
            mask = mask_features
        )

    def add_adjust_positions_to_tracks(self,tracks, camera_movement_per_frame):
        for object, object_tracks in tracks.items():
            for frame_num, track in enumerate(object_tracks):
                for track_id, track_info in track.items():
                    position = track_info['position']
                    camera_movement = camera_movement_per_frame[frame_num]
                    position_adjusted = (position[0]-camera_movement[0],position[1]-camera_movement[1])
                    tracks[object][frame_num][track_id]['position_adjusted'] = position_adjusted
                    


    def get_camera_movement(self,frames,read_from_stub=False, stub_path=None):
        # Read the stub 
        if read_from_stub and stub_path is not None and os.path.exists(stub_path):
            with open(stub_path,'rb') as f:
                return pickle.load(f)

        camera_movement = [[0,0]]*len(frames)

        old_gray = cv2.cvtColor(frames[0],cv2.COLOR_BGR2GRAY)
        old_features = cv2.goodFeaturesToTrack(old_gray,**self.features)
        if old_features is None:
            # No initial features; cannot compute camera movement
            return [[0,0] for _ in frames]
        for frame_num in range(1,len(frames)):
            frame_gray = cv2.cvtColor(frames[frame_num],cv2.COLOR_BGR2GRAY)
            # Ensure old_features is valid before optical flow
            if old_features is None:
                old_features = cv2.goodFeaturesToTrack(old_gray,**self.features)
                if old_features is None:
                    continue
            new_features, _, _ = cv2.calcOpticalFlowPyrLK(old_gray, frame_gray, old_features, None, **self.lk_params)
            # If calc fails or returns None, recompute features for next iteration
            if new_features is None:
                old_features = cv2.goodFeaturesToTrack(frame_gray, **self.features)
                old_gray = frame_gray.copy()
                continue

            max_distance = 0
            camera_movement_x, camera_movement_y = 0,0

            for i, (new,old) in enumerate(zip(new_features,old_features)):
                new_features_point = new.ravel()
                old_features_point = old.ravel()

                distance = measure_distance(new_features_point,old_features_point)
                if distance>max_distance:
                    max_distance = distance
                    camera_movement_x,camera_movement_y = measure_xy_distance(old_features_point, new_features_point ) 
            
            if max_distance > self.minimum_distance:
                camera_movement[frame_num] = [camera_movement_x,camera_movement_y]
                old_features = cv2.goodFeaturesToTrack(frame_gray,**self.features)

            old_gray = frame_gray.copy()
        
        if stub_path is not None:
            with open(stub_path,'wb') as f:
                pickle.dump(camera_movement,f)

        return camera_movement
    
    def draw_camera_movement(self,frames, camera_movement_per_frame):
        output_frames=[]

        for frame_num, frame in enumerate(frames):
            frame= frame.copy()
            h, w = frame.shape[:2]

            # Scale overlay to frame size (reference 1920px wide)
            scale = w / 1920.0
            box_w = int(500 * scale)
            box_h = int(100 * scale)
            font_scale = max(0.3, 0.85 * scale)
            thickness = max(1, int(2.5 * scale))
            line_h = int(30 * scale)

            overlay = frame.copy()
            cv2.rectangle(overlay,(0,0),(box_w, box_h),(255,255,255),-1)
            alpha =0.6
            cv2.addWeighted(overlay,alpha,frame,1-alpha,0,frame)

            x_movement, y_movement = camera_movement_per_frame[frame_num]
            pad = int(10 * scale)
            frame = cv2.putText(frame,f"Camera Movement X: {x_movement:.2f}",(pad, pad + line_h), cv2.FONT_HERSHEY_SIMPLEX, font_scale,(0,0,0), thickness)
            frame = cv2.putText(frame,f"Camera Movement Y: {y_movement:.2f}",(pad, pad + line_h * 2), cv2.FONT_HERSHEY_SIMPLEX, font_scale,(0,0,0), thickness)

            output_frames.append(frame) 

        return output_frames