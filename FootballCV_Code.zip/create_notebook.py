import json
import os

notebook_content = {
 "cells": [
  {
   "cell_type": "markdown",
   "metadata": {},
   "source": [
    "# AI/ML Football Analysis Project\n",
    "\n",
    "## Project Overview\n",
    "This project builds an end-to-end AI/ML Football Analysis system. We will use computer vision techniques to track players, referees, and the ball, assign players to teams based on jersey colors, and estimate their speed and distance covered.\n",
    "\n",
    "### Problem Statement\n",
    "Analyzing football match footage is challenging due to camera movement, occlusions, and the fast pace of the game. Our goal is to extract meaningful analytics (possession, speed, distance) from raw broadcast video using deep learning.\n",
    "\n",
    "### Dataset\n",
    "- **Kaggle Dataset**: DFL Bundesliga Data Shootout (for raw video clips)\n",
    "- **Roboflow Dataset**: Custom annotated football dataset used for fine-tuning YOLOv8."
   ]
  },
  {
   "cell_type": "markdown",
   "metadata": {},
   "source": [
    "## 1. Setup & Installation"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": None,
   "metadata": {},
   "outputs": [],
   "source": [
    "!pip install ultralytics opencv-python scikit-learn pandas numpy matplotlib filterpy lapx"
   ]
  },
  {
   "cell_type": "markdown",
   "metadata": {},
   "source": [
    "## 2. Import Libraries"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": None,
   "metadata": {},
   "outputs": [],
   "source": [
    "import cv2\n",
    "import numpy as np\n",
    "import pandas as pd\n",
    "from ultralytics import YOLO\n",
    "import matplotlib.pyplot as plt\n",
    "import sys\n",
    "import os\n",
    "\n",
    "# Import custom modules (ensure you are running this in the project root)\n",
    "from trackers import Tracker\n",
    "from team_assigner import TeamAssigner\n",
    "from player_ball_assigner import PlayerBallAssigner\n",
    "from camera_movement_estimator import CameraMovementEstimator\n",
    "from view_transformer import ViewTransformer\n",
    "from speed_and_distance_estimator import SpeedAndDistance_Estimator\n",
    "from utils import read_video, save_video"
   ]
  },
  {
   "cell_type": "markdown",
   "metadata": {},
   "source": [
    "## 3. Data Collection & Preprocessing\n",
    "We load a sample video clip to perform EDA on the frames."
   ]
  },
  {
   "cell_type": "code",
   "execution_count": None,
   "metadata": {},
   "outputs": [],
   "source": [
    "video_path = 'input_videos/sample_match.mp4' # Replace with actual path\n",
    "# Read video frames\n",
    "try:\n",
    "    video_frames = read_video(video_path)\n",
    "    print(f\"Loaded {len(video_frames)} frames from {video_path}\")\n",
    "except:\n",
    "    print(\"Please place a video file in input_videos/ and update the path above.\")"
   ]
  },
  {
   "cell_type": "markdown",
   "metadata": {},
   "source": [
    "## 4. Model Building (YOLOv8)\n",
    "We load a pre-trained YOLOv8 model. In a full training pipeline, we would train it using `model.train(data='data.yaml', epochs=100)`. Here we load the trained weights `best.pt` or use the standard `yolov8x.pt`."
   ]
  },
  {
   "cell_type": "code",
   "execution_count": None,
   "metadata": {},
   "outputs": [],
   "source": [
    "model_path = 'models/best.pt' if os.path.exists('models/best.pt') else 'yolov8x.pt'\n",
    "tracker = Tracker(model_path)\n",
    "print(f\"Loaded model from {model_path}\")"
   ]
  },
  {
   "cell_type": "markdown",
   "metadata": {},
   "source": [
    "## 5. Evaluation & Inference\n",
    "We run the tracker on our video frames."
   ]
  },
  {
   "cell_type": "code",
   "execution_count": None,
   "metadata": {},
   "outputs": [],
   "source": [
    "# Get object tracks\n",
    "if 'video_frames' in locals():\n",
    "    tracks = tracker.get_object_tracks(video_frames, read_from_stub=False)\n",
    "    tracker.add_position_to_tracks(tracks)\n",
    "    print(\"Tracking complete.\")"
   ]
  },
  {
   "cell_type": "markdown",
   "metadata": {},
   "source": [
    "## 6. Advanced Analytics (Optical Flow & K-Means)\n",
    "We apply Optical Flow for camera movement, View Transformation for perspective, and K-Means clustering for team color assignment."
   ]
  },
  {
   "cell_type": "code",
   "execution_count": None,
   "metadata": {},
   "outputs": [],
   "source": [
    "if 'video_frames' in locals():\n",
    "    # Camera movement estimator\n",
    "    camera_estimator = CameraMovementEstimator(video_frames[0])\n",
    "    camera_movement_per_frame = camera_estimator.get_camera_movement(video_frames, read_from_stub=False)\n",
    "    camera_estimator.add_adjust_positions_to_tracks(tracks, camera_movement_per_frame)\n",
    "\n",
    "    # View Transformer\n",
    "    view_transformer = ViewTransformer()\n",
    "    view_transformer.add_transformed_position_to_tracks(tracks)\n",
    "\n",
    "    # Interpolate Ball Positions\n",
    "    tracks[\"ball\"] = tracker.interpolate_ball_positions(tracks[\"ball\"])\n",
    "\n",
    "    # Speed and distance estimator\n",
    "    speed_and_distance_estimator = SpeedAndDistance_Estimator()\n",
    "    speed_and_distance_estimator.add_speed_and_distance_to_tracks(tracks)\n",
    "\n",
    "    # Assign Player Teams\n",
    "    team_assigner = TeamAssigner()\n",
    "    team_assigner.assign_team_color(video_frames[0], tracks['players'][0])\n",
    "    \n",
    "    for frame_num, player_track in enumerate(tracks['players']):\n",
    "        for player_id, track in player_track.items():\n",
    "            team = team_assigner.get_player_team(video_frames[frame_num], track['bbox'], player_id)\n",
    "            tracks['players'][frame_num][player_id]['team'] = team \n",
    "            tracks['players'][frame_num][player_id]['team_color'] = team_assigner.team_colors[team]\n",
    "\n",
    "    # Assign Ball Aquisition\n",
    "    player_assigner = PlayerBallAssigner()\n",
    "    team_ball_control = []\n",
    "    for frame_num, player_track in enumerate(tracks['players']):\n",
    "        ball_bbox = tracks['ball'][frame_num][1]['bbox']\n",
    "        assigned_player = player_assigner.assign_ball_to_player(player_track, ball_bbox)\n",
    "\n",
    "        if assigned_player != -1:\n",
    "            tracks['players'][frame_num][assigned_player]['has_ball'] = True\n",
    "            team_ball_control.append(tracks['players'][frame_num][assigned_player]['team'])\n",
    "        else:\n",
    "            if team_ball_control:\n",
    "                team_ball_control.append(team_ball_control[-1])\n",
    "            else:\n",
    "                team_ball_control.append(1) \n",
    "    \n",
    "    team_ball_control = np.array(team_ball_control)\n",
    "    print(\"Advanced analytics complete.\")"
   ]
  },
  {
   "cell_type": "markdown",
   "metadata": {},
   "source": [
    "## 7. Saving the Processed Video\n",
    "Draw all annotations (bounding boxes, team colors, speed, distance) and save the video."
   ]
  },
  {
   "cell_type": "code",
   "execution_count": None,
   "metadata": {},
   "outputs": [],
   "source": [
    "if 'video_frames' in locals():\n",
    "    output_video_frames = tracker.draw_annotations(video_frames, tracks, team_ball_control)\n",
    "    output_video_frames = camera_estimator.draw_camera_movement(output_video_frames, camera_movement_per_frame)\n",
    "    speed_and_distance_estimator.draw_speed_and_distance(output_video_frames, tracks)\n",
    "\n",
    "    output_path = \"output_videos/analysis_result.avi\"\n",
    "    os.makedirs(\"output_videos\", exist_ok=True)\n",
    "    save_video(output_video_frames, output_path)\n",
    "    print(f\"Processed video saved to {output_path}\")"
   ]
  },
  {
   "cell_type": "markdown",
   "metadata": {},
   "source": [
    "## 8. Deployment Links\n",
    "\n",
    "- **GitHub Repository**: [Your GitHub Repo Link Here]\n",
    "- **Streamlit Application**: [Your Streamlit App URL Here]"
   ]
  }
 ],
 "metadata": {
  "kernelspec": {
   "display_name": "Python 3",
   "language": "python",
   "name": "python3"
  },
  "language_info": {
   "codemirror_mode": {
    "name": "ipython",
    "version": 3
   },
   "file_extension": ".py",
   "mimetype": "text/x-python",
   "name": "python",
   "nbconvert_exporter": "python",
   "pygments_lexer": "ipython3",
   "version": "3.8.0"
  }
 },
 "nbformat": 4,
 "nbformat_minor": 4
}

with open(r"c:\Users\MuditSajal\OneDrive - CloudThat\Desktop\MinP\football_analysis.ipynb", "w", encoding="utf-8") as f:
    json.dump(notebook_content, f, indent=1)
